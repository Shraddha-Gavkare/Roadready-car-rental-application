# RoadReady-Backend-API-Car-rental-system
A Spring Boot-based backend for the RoadReady Car Rental System with JWT authentication, REST APIs, and MySQL integration.

Google drive Link:
https://drive.google.com/drive/folders/1xHif18KF8EZsyEO38sUin_JuRa8FA9Xu?usp=sharing

Documentation with Project screenshot:
https://drive.google.com/file/d/1a3xJQfTVQCTv2Le61mrFlHJEdcbiV-XK/view?usp=sharing

PPT Link:
https://docs.google.com/presentation/d/1J23Kvg0BLyXs0QecRR4TOmfGOSbIWx5_/edit?usp=sharing&ouid=113278176976337080858&rtpof=true&sd=true

Video Demonstration:
https://drive.google.com/file/d/130Bg1MMEvNvKKaexvEOxXjHF5I19Isvc/view?usp=sharing
