package com.example.demo.service;

import com.example.demo.entity.Reservation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendReservationConfirmation(Reservation reservation) {
        if (reservation.getUser() == null || reservation.getUser().getEmail() == null) return;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(reservation.getUser().getEmail());
        message.setSubject("✅ RoadReady: Reservation Confirmed");
        message.setText("Dear " + reservation.getUser().getName() + ",\n\n"
                + "Your car reservation has been successfully confirmed!\n\n"
                + "Reservation Details:\n"
                + "Car: " + reservation.getCar().getBrand() + " " + reservation.getCar().getModel() + "\n"
                + "Start Date: " + reservation.getStartDate() + "\n"
                + "End Date: " + reservation.getEndDate() + "\n"
                + "Pickup Location: " + reservation.getPickupLocation() + "\n"
                + "Dropoff Location: " + reservation.getDropoffLocation() + "\n\n"
                + "Thank you for choosing RoadReady 🚗");

        mailSender.send(message);
    }
}
