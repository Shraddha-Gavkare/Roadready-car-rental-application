package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "reservations")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reservation {

 
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private LocalDate startDate;
private LocalDate endDate;
private String status; // PENDING, CONFIRMED, CANCELLED
private String pickupLocation;
private String dropoffLocation;

 
@OneToMany(mappedBy = "reservation", cascade = CascadeType.ALL)
@JsonManagedReference
private List<Payment> payments;

@ManyToOne(fetch = FetchType.EAGER) // 👈 should not be LAZY
@JoinColumn(name = "user_id")
@JsonIgnore
private User user;


@ManyToOne
@JoinColumn(name = "car_id")
@JsonIgnore
private Car car;
}