// src/main/java/com/example/demo/dto/ReservationDTO.java
package com.example.demo.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class ReservationDTO {
    private Long id;
    private LocalDate startDate;
    private LocalDate endDate;
    private String pickupLocation;
    private String dropoffLocation;
    private String status;
    private String userEmail;

    public ReservationDTO() {}

    public ReservationDTO(Long id, LocalDate startDate, LocalDate endDate,
                          String pickupLocation, String dropoffLocation,
                          String status, String userEmail) {
        this.id = id;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pickupLocation = pickupLocation;
        this.dropoffLocation = dropoffLocation;
        this.status = status;
        this.userEmail = userEmail;
    }

    // Getters & setters (or use Lombok @Data)
}
