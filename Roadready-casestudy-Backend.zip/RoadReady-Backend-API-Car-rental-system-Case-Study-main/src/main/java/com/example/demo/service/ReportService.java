// src/main/java/com/example/demo/service/ReportService.java
package com.example.demo.service;

import com.example.demo.dto.ReportDTO;
import java.util.List;

public interface ReportService {
    ReportDTO getTotalRevenue();
    ReportDTO getUsageStats(); // Reservations count, etc.
}
