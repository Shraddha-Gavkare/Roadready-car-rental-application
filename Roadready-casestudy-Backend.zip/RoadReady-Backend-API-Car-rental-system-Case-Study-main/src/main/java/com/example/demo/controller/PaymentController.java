package com.example.demo.controller;

import com.example.demo.dto.PaymentDTO;
import com.example.demo.dto.PaymentRequestDTO;
import com.example.demo.entity.Payment;
import com.example.demo.entity.Reservation;
import com.example.demo.entity.User;
import com.example.demo.service.PaymentService;
import com.example.demo.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.example.demo.dto.PaymentWithReservationDTO;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ReservationService reservationService;

    @PostMapping
    public ResponseEntity<?> makePayment(@RequestBody PaymentRequestDTO dto) {
        Reservation reservation = reservationService.getReservationById(dto.getReservationId()).orElse(null);

        if (reservation == null) {
            return ResponseEntity.badRequest().body("Invalid reservation ID");
        }

        Payment payment = Payment.builder()
                .reservation(reservation)
                  // ✅ fix: use BigDecimal
                .amount(dto.getAmount())  // ✅ CORRECT
                .paymentMethod((String) dto.getPaymentMethod())
                .paymentStatus("SUCCESS")
                .paymentDate(LocalDateTime.now())
                .user(reservation.getUser()) // set user from reservation
                .build();

        Payment saved = paymentService.makePayment(payment);

        PaymentDTO response = new PaymentDTO(
            saved.getId(),
            saved.getAmount(),
            saved.getPaymentStatus(),
            saved.getPaymentMethod(),
            saved.getPaymentDate(),
            saved.getReservation() != null ? saved.getReservation().getId() : null,
            saved.getUser() != null ? saved.getUser().getEmail() : null
        );

        return ResponseEntity.ok(response);
    }

    
    @GetMapping("/reservation/{reservationId}")
    public ResponseEntity<?> getPaymentByReservation(@PathVariable Long reservationId) {
        Reservation reservation = reservationService.getReservationById(reservationId).orElse(null);

        if (reservation == null) {
            return ResponseEntity.badRequest().body("Invalid reservation ID");
        }

        Optional<Payment> paymentOpt = paymentService.getPaymentByReservation(reservation);

        if (paymentOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("No payment found for this reservation.");
        }

        Payment payment = paymentOpt.get();

        PaymentWithReservationDTO dto = new PaymentWithReservationDTO(
            payment.getId(),
            payment.getAmount(),
            payment.getPaymentMethod(),
            payment.getPaymentStatus(),
            payment.getPaymentDate(),

            reservation.getId(),
            reservation.getStartDate(),
            reservation.getEndDate(),
            reservation.getPickupLocation(),
            reservation.getDropoffLocation(),
            reservation.getStatus()
        );

        return ResponseEntity.ok(dto);
    }


    
    
    
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/all")
    public ResponseEntity<List<PaymentDTO>> getAllPayments() {
        List<Payment> payments = paymentService.getAllPayments();

        List<PaymentDTO> paymentDTOs = payments.stream()
                .map(p -> new PaymentDTO(
                        p.getId(),
                        p.getAmount(),
                        p.getPaymentStatus(),
                        p.getPaymentMethod(),
                        p.getPaymentDate(),
                        p.getReservation() != null ? p.getReservation().getId() : null,
                        p.getUser() != null ? p.getUser().getEmail() : null
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(paymentDTOs);
    }
}
