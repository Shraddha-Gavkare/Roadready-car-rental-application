// src/main/java/com/example/demo/service/ReportServiceImpl.java
package com.example.demo.service;

import com.example.demo.dto.ReportDTO;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Override
    public ReportDTO getTotalRevenue() {
        BigDecimal total = paymentRepository.sumTotalRevenue();
        return new ReportDTO("Total Revenue", total != null ? total : BigDecimal.ZERO);
    }

    @Override
    public ReportDTO getUsageStats() {
        long totalReservations = reservationRepository.count();
        return new ReportDTO("Total Reservations", totalReservations);
    }
}
