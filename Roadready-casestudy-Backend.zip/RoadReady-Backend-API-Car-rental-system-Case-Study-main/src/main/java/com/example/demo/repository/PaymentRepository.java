package com.example.demo.repository;


import com.example.demo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entity.Payment;

import java.math.BigDecimal;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByReservation(Reservation reservation);
    
 // src/main/java/com/example/demo/repository/PaymentRepository.java
    @Query("SELECT SUM(p.amount) FROM Payment p")
    BigDecimal sumTotalRevenue();

}


 