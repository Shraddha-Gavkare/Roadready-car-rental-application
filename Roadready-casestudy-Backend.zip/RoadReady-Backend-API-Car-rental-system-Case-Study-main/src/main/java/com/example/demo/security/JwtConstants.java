package com.example.demo.security;

 

public class JwtConstants {
    public static final long EXPIRATION = 86400000L; // 1 day in ms
    public static final String SECRET = "SecretKeyForJWTGeneration";
}
