package com.example.demo.config;

import com.example.demo.security.JwtAuthenticationFilter;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

	 
@Autowired
private JwtAuthenticationFilter jwtFilter;

@Bean
public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	http
    .csrf(csrf -> csrf.disable())
    .authorizeHttpRequests(auth -> auth
        .requestMatchers(
            "/swagger-ui/**",
            "/swagger-ui.html",
            "/v3/api-docs/**",
            "/swagger-resources/**",
            "/webjars/**",
            "/configuration/ui",
            "/configuration/security"
        ).permitAll()
        .requestMatchers("/api/auth/**").permitAll()
        .requestMatchers("/api/cars/**").permitAll()

        // 👇 Fix: Admin-only access to all payments
        .requestMatchers("/api/payments/all").hasRole("ADMIN")
        .requestMatchers("/api/reservations/all").hasRole("ADMIN")
         

        .requestMatchers("/api/users/me").hasRole("CUSTOMER")
        // 👇 Customer APIs
        .requestMatchers("/api/payments/**").hasRole("CUSTOMER")
         
        .requestMatchers("/api/reservations/**").hasAnyRole("CUSTOMER", "ADMIN")
        
        .requestMatchers("/api/users/**").hasRole("ADMIN")
        .requestMatchers("/api/users/me").hasRole("CUSTOMER")
        
         
        .requestMatchers("/api/reservations/**", "/api/users/me").hasAnyRole("CUSTOMER", "ADMIN")
        
        // 👇 All other requests need authentication
        .anyRequest().authenticated()
        
    )
    .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
	return http.build();
}

}


