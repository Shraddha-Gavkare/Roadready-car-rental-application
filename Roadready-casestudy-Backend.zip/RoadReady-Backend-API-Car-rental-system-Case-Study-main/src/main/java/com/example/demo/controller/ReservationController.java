package com.example.demo.controller;

import com.example.demo.dto.*;
import com.example.demo.entity.Car;
import com.example.demo.entity.Reservation;
import com.example.demo.entity.User;
import com.example.demo.service.CarService;
import com.example.demo.service.ReservationService;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/reservations")
@CrossOrigin
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private UserService userService;

    @Autowired
    private CarService carService;

    // Customer creates reservation
    @PostMapping
    public ResponseEntity<?> createReservation(@RequestBody ReservationRequestDTO dto, Principal principal) {
        Optional<User> userOpt = userService.getUserByEmail(principal.getName());
        Optional<Car> carOpt = carService.getCarById(dto.getCarId());

        if (userOpt.isEmpty() || carOpt.isEmpty() || !carOpt.get().isAvailable()) {
            return ResponseEntity.badRequest().body("Invalid user or car not available");
        }

        Car car = carOpt.get();
        car.setAvailable(false);
        carService.updateCar(car);

        User user = userOpt.get(); // ✅ Ensured user is retrieved correctly
        

        Reservation reservation = Reservation.builder()
                .user(user) // ✅ SET the user here
                .car(car)
                .startDate(dto.getStartDate())
                .endDate(dto.getEndDate())
                .pickupLocation(dto.getPickupLocation())
                .dropoffLocation(dto.getDropoffLocation())
                .status("PENDING")
                .build();

        Reservation saved = reservationService.createReservation(reservation);

        ReservationResponseDTO responseDTO = ReservationResponseDTO.builder()
                .id(saved.getId())
                .carId(saved.getCar().getId())
                .carBrand(saved.getCar().getBrand())
                .carModel(saved.getCar().getModel())
                .startDate(saved.getStartDate())
                .endDate(saved.getEndDate())
                .pickupLocation(saved.getPickupLocation())
                .dropoffLocation(saved.getDropoffLocation())
                .status(saved.getStatus())
                .build();

        return ResponseEntity.ok(responseDTO);
    }

    // View all reservations for the current customer
    @GetMapping
    public ResponseEntity<List<ReservationResponseDTO>> getUserReservations(Principal principal) {
        Optional<User> userOpt = userService.getUserByEmail(principal.getName());
        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<Reservation> reservations = reservationService.getReservationsByUser(userOpt.get());

        List<ReservationResponseDTO> responseList = reservations.stream().map(saved -> ReservationResponseDTO.builder()
                .id(saved.getId())
                .carId(saved.getCar().getId())
                .carBrand(saved.getCar().getBrand())
                .carModel(saved.getCar().getModel())
                .startDate(saved.getStartDate())
                .endDate(saved.getEndDate())
                .pickupLocation(saved.getPickupLocation())
                .dropoffLocation(saved.getDropoffLocation())
                .status(saved.getStatus())
                .build()).collect(Collectors.toList());

        return ResponseEntity.ok(responseList);
    }

    // Cancel reservation (Can restrict to user or admin as needed)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancelReservation(@PathVariable Long id) {
        reservationService.cancelReservation(id);
        return ResponseEntity.noContent().build();
    }

    // Admin-only: Get all reservations
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/all")
    public ResponseEntity<List<ReservationDTO>> getAllReservations() {
        List<Reservation> reservations = reservationService.getAllReservations();

        List<ReservationDTO> dtos = reservations.stream()
                .map(r -> new ReservationDTO(
                        r.getId(),
                        r.getStartDate(),
                        r.getEndDate(),
                        r.getPickupLocation(),
                        r.getDropoffLocation(),
                        r.getStatus(),
                        r.getUser() != null ? r.getUser().getEmail() : null
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }
}
