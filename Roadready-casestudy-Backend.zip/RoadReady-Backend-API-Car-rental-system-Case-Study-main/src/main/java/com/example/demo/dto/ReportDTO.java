// src/main/java/com/example/demo/dto/ReportDTO.java
package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ReportDTO {
    private String title;
    private Object value;
}
