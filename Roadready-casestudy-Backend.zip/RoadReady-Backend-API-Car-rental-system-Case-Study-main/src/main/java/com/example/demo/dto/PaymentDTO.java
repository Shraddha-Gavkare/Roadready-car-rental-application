package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDTO {

    private Long id;
    private BigDecimal amount;     // ✅ Use BigDecimal to match Payment entity
    private String paymentStatus;  // ✅ Align with entity's field name
    private String paymentMethod;  // ✅ Align with entity's field name
    private LocalDateTime paymentDate;
    private Long reservationId;
    private String userEmail;
}
 
 
 
