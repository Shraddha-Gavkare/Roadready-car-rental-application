package com.example.demo.service;

import com.example.demo.entity.Car;
import com.example.demo.repository.CarRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import java.util.*;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CarServiceImplTest {

    @Mock
    private CarRepository carRepository;

    @InjectMocks
    private CarServiceImpl carService;

    private Car testCar;

    @BeforeEach
    void setUp() {
        testCar = Car.builder()
                .id(1L)
                .brand("Toyota")
                .model("Corolla")
                .year(2020)
                .available(true)
                .licensePlate("MH12AB1234")
                .pricePerDay(BigDecimal.valueOf(1500.0)) // ✅ FIXED
                .color("White")
                .type("Sedan")
                .build();
    }


    @Test
    void testAddCar() {
        when(carRepository.save(testCar)).thenReturn(testCar);

        Car savedCar = carService.addCar(testCar);

        assertEquals(testCar, savedCar);
        verify(carRepository, times(1)).save(testCar);
    }

    @Test
    void testGetAllCars() {
        List<Car> carList = List.of(testCar);
        when(carRepository.findAll()).thenReturn(carList);

        List<Car> result = carService.getAllCars();

        assertEquals(1, result.size());
        verify(carRepository).findAll();
    }

    @Test
    void testGetCarById() {
        when(carRepository.findById(1L)).thenReturn(Optional.of(testCar));

        Optional<Car> result = carService.getCarById(1L);

        assertTrue(result.isPresent());
        assertEquals(testCar.getBrand(), result.get().getBrand());
    }

    @Test
    void testDeleteCar() {
        Long carId = 1L;
        carService.deleteCar(carId);

        verify(carRepository, times(1)).deleteById(carId);
    }

    @Test
    void testUpdateCar() {
        testCar.setColor("Red");
        when(carRepository.save(testCar)).thenReturn(testCar);

        Car updatedCar = carService.updateCar(testCar);

        assertEquals("Red", updatedCar.getColor());
        verify(carRepository).save(testCar);
    }

    @Test
    void testGetAvailableCars() {
        List<Car> availableCars = List.of(testCar);
        when(carRepository.findByAvailable(true)).thenReturn(availableCars);

        List<Car> result = carService.getAvailableCars();

        assertEquals(1, result.size());
        assertTrue(result.get(0).isAvailable());
    }
}
