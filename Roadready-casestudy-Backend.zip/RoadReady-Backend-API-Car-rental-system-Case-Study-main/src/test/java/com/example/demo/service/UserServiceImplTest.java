package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserServiceImpl userService;

    private User mockUser;

    @BeforeEach
    void setUp() {
        mockUser = new User();
        mockUser.setId(1L);
        mockUser.setName("Shraddha");
        mockUser.setEmail("shraddha@example.com");
        mockUser.setPhone("9876543210");
        mockUser.setRole("CUSTOMER");
        mockUser.setAddress("Pune");
    }

    @Test
    void testRegisterUser() {
        when(userRepository.save(mockUser)).thenReturn(mockUser);

        User savedUser = userService.registerUser(mockUser);

        assertNotNull(savedUser);
        assertEquals("Shraddha", savedUser.getName());
        verify(userRepository, times(1)).save(mockUser);
    }

    @Test
    void testGetUserByEmail_Found() {
        when(userRepository.findByEmail("shraddha@example.com")).thenReturn(Optional.of(mockUser));

        Optional<User> result = userService.getUserByEmail("shraddha@example.com");

        assertTrue(result.isPresent());
        assertEquals("Shraddha", result.get().getName());
    }

    @Test
    void testGetUserByEmail_NotFound() {
        when(userRepository.findByEmail("unknown@example.com")).thenReturn(Optional.empty());

        Optional<User> result = userService.getUserByEmail("unknown@example.com");

        assertFalse(result.isPresent());
    }

    @Test
    void testGetAllUsers() {
        List<User> userList = List.of(mockUser);
        when(userRepository.findAll()).thenReturn(userList);

        List<User> result = userService.getAllUsers();

        assertEquals(1, result.size());
        assertEquals("Shraddha", result.get(0).getName());
    }

    @Test
    void testGetUserById_Found() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));

        Optional<User> result = userService.getUserById(1L);

        assertTrue(result.isPresent());
        assertEquals("Shraddha", result.get().getName());
    }

    @Test
    void testDeleteUser() {
        doNothing().when(userRepository).deleteById(1L);

        userService.deleteUser(1L);

        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteUserById_Success() {
        when(userRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRepository).deleteById(1L);

        boolean result = userService.deleteUserById(1L);

        assertTrue(result);
        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteUserById_Failure() {
        when(userRepository.existsById(99L)).thenReturn(false);

        boolean result = userService.deleteUserById(99L);

        assertFalse(result);
        verify(userRepository, never()).deleteById(99L);
    }
}
