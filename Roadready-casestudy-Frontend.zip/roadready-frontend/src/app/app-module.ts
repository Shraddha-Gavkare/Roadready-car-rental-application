import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { App } from './app';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing-module';


// ✅ Import standalone components
import { Login } from './auth/login/login';
import { Register } from './auth/register/register';
import { CustomerDashboard } from './dashboard/customer-dashboard/customer-dashboard';
import { AdminDashboard } from './dashboard/admin-dashboard/admin-dashboard';
import { CarList } from './car/car-list/car-list';
import { AddCar } from './dashboard/admin-dashboard/add-car/add-car';
import { ReservationList } from './reservation/reservation-list/reservation-list';
import { ReservationForm } from './reservation/reservation-form/reservation-form';
import { PaymentForm } from './payment/payment-form/payment-form';
import { PaymentList } from './payment/payment-list/payment-list';

import { Navbar } from './shared/navbar/navbar';
 
import { AuthGuard } from './shared/guards/auth.guard/auth.guard';
import { AdminSidebar } from './dashboard/admin-dashboard/admin-sidebar/admin-sidebar';
import { AdminNavbar } from './dashboard/admin-dashboard/admin-navbar/admin-navbar';
import { AdminFooter } from './dashboard/admin-dashboard/admin-footer/admin-footer';
import { CarManagement } from './dashboard/admin-dashboard/car-management/car-management';
import { ViewReservations } from './dashboard/admin-dashboard/view-reservations/view-reservations';
import { AdminReservations } from './dashboard/admin-reservations/admin-reservations';
import { AdminPayments } from './dashboard/admin-payments/admin-payments';
import { ViewUsers } from './view-users/view-users';
import { CustomerProfile } from './dashboard/customer-dashboard/customer-profile';
import { AboutUs } from './components/about-us/about-us';

@NgModule({
  declarations: [
    App
  ],
  
  imports: [
    BrowserModule,
    AboutUs,
    CustomerProfile,
    HttpClientModule,
    AdminPayments,
    ViewUsers,
    FormsModule,
    ViewReservations,
    AdminReservations,
    ReactiveFormsModule,

    // ✅ Standalone Components
    Login,
    Register,
    CustomerDashboard,
    AdminDashboard,
    AddCar,
    CarList,
    AddCar,
    ReservationList,
    ReservationForm,
    PaymentForm,
    PaymentList,
    Navbar,
    CarManagement,        // ✅ moved to imports only
    AdminSidebar,
    AdminNavbar,
    AdminFooter,

    AppRoutingModule
  ],
  bootstrap: [App]
})
export class AppModule { }

