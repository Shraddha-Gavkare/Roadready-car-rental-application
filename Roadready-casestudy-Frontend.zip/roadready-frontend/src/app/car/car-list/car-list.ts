import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CarService } from '../../services/car.service/car.service';

@Component({
selector: 'app-car-list',
templateUrl: './car-list.html',
styleUrls: ['./car-list.css'],
standalone: true,
imports: [CommonModule]
})
export class CarList implements OnInit {
cars: any[] = [];

constructor(
private carService: CarService,
private router: Router
) {}

ngOnInit(): void {
this.loadCars();
}

loadCars(): void {
this.carService.getAllCars().subscribe({
next: (data: any[]) => {
console.log('Received cars:', data);
this.cars = data;
},
error: (err: any) => {
console.error('Error fetching cars:', err);
}
});
}

goToReserve(carId: number): void {
this.router.navigate(['/reserve'], { queryParams: { carId } });
}
}