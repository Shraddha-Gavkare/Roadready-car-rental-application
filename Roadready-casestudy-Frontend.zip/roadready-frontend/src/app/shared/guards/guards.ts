import { Component } from '@angular/core';

@Component({
  selector: 'app-guards',
  standalone: false,
  templateUrl: './guards.html',
  styleUrl: './guards.css'
})
export class Guards {

}
