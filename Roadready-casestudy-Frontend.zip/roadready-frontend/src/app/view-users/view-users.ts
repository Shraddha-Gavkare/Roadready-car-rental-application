import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // ✅ Required for *ngFor
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-view-users',
  standalone: true,
  imports: [CommonModule], // ✅ Add this line
  templateUrl: './view-users.html',
  styleUrls: ['./view-users.css']
})
export class ViewUsers implements OnInit {
  users: any[] = [];

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
  this.userService.getAllUsers().subscribe({
    next: (data: any[]) => this.users = data,
    error: (err: any) => console.error('Error fetching users:', err)
  });
}

deleteUser(id: number): void {
  if (confirm('Are you sure you want to delete this user?')) {
    this.userService.deleteUser(id).subscribe({
      next: () => {
        alert('User deleted successfully');
        this.loadUsers();
      },
      error: (err: any) => alert('Error deleting user: ' + err.message)
    });
  }
}

}
