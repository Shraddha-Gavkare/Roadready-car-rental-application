import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';

@Injectable({ providedIn: 'root' })
export class PaymentService {
  private baseUrl = 'http://localhost:8080/api/payments';
  private isBrowser: boolean;

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId); // ✅ SSR-safe
  }

  // 🔁 POST: Make a new payment
  makePayment(data: any) {
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    if (this.isBrowser) {
      const token = localStorage.getItem('token');
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    }

    return this.http.post(this.baseUrl, data, { headers });
  }

  // 📥 GET: Retrieve logged-in user's payments with reservationId
  getPaymentByReservationId(reservationId: number) {
    let headers = new HttpHeaders();

    if (this.isBrowser) {
      const token = localStorage.getItem('token');
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    }
    return this.http.get(`${this.baseUrl}/reservation/${reservationId}`, { headers });
  }

  getAllPayments(): Observable<any[]> {
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    if (this.isBrowser) {
      const token = localStorage.getItem('token');
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    }

    return this.http.get<any[]>(`${this.baseUrl}/all`, { headers });
  }
}
