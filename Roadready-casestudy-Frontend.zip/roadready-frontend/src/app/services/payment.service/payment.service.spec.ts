import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentService } from './payment.service';

describe('PaymentService', () => {
  let component: PaymentService;
  let fixture: ComponentFixture<PaymentService>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PaymentService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
