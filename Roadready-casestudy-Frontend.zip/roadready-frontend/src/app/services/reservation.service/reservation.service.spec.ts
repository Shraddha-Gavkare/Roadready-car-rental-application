import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservationService } from './reservation.service';

describe('ReservationService', () => {
  let component: ReservationService;
  let fixture: ComponentFixture<ReservationService>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReservationService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReservationService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
