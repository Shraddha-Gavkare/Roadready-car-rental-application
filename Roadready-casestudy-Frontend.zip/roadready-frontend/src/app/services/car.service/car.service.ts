import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
providedIn: 'root'
})
export class CarService {

private baseUrl = 'http://localhost:8080/api/cars';

constructor(private http: HttpClient) {}

// ✅ Add Car
addCar(car: any): Observable<any> {
return this.http.post<any>(this.baseUrl, car);
}

// ✅ Get All Cars
getAllCars(): Observable<any[]> {
return this.http.get<any[]>(this.baseUrl);
}

getCarById(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${id}`);
  }

  getAvailableCars(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/available`);
  }
  
  updateCar(id: number, car: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/${id}`, car);
  }

  deleteCar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

 
}
 