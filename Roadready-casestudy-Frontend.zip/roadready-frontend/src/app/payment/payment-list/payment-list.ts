import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { PaymentService } from '../../services/payment.service/payment.service';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-payment-list',
  standalone: true,
  templateUrl: './payment-list.html',
  styleUrls: ['./payment-list.css'],
  imports: [CommonModule, ReactiveFormsModule],
  providers: [DatePipe]
})
export class PaymentList implements OnInit {
  reservationIdForm: FormGroup;
  paymentData: any = null;
  errorMessage = '';

  constructor(private fb: FormBuilder, private paymentService: PaymentService) {
    this.reservationIdForm = this.fb.group({
      reservationId: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  fetchPayment() {
    if (this.reservationIdForm.invalid) {
      this.errorMessage = 'Reservation ID is required';
      return;
    }

    const reservationId = this.reservationIdForm.value.reservationId;

    this.paymentService.getPaymentByReservationId(reservationId).subscribe({
      next: (data) => {
        this.paymentData = data;
        this.errorMessage = '';
      },
      error: (err) => {
        this.paymentData = null;
        this.errorMessage = 'Payment not found for the given reservation ID.';
        console.error(err);
      }
    });
  }
}
