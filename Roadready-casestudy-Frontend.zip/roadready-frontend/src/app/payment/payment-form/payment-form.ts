import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
selector: 'app-payment-form',
standalone: true,
imports: [CommonModule, ReactiveFormsModule],
templateUrl: './payment-form.html',
styleUrls: ['./payment-form.css']
})
export class PaymentForm {
paymentForm: FormGroup;
errorMessage = '';
successMessage = '';

constructor(
private fb: FormBuilder,
private http: HttpClient,
private router: Router
) {
this.paymentForm = this.fb.group({
reservationId: ['', Validators.required],
amount: ['', [Validators.required, Validators.min(1)]],
paymentMethod: ['', Validators.required]
});
}

onSubmit() {
if (this.paymentForm.invalid) {
this.errorMessage = '❌ All fields are required.';
this.successMessage = '';
return;
}

const token = localStorage.getItem('token');
const headers = new HttpHeaders({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${token}`
});

this.http.post('http://localhost:8080/api/payments', this.paymentForm.value, { headers })
  .subscribe({
    next: () => {
      this.successMessage = '✅ Payment successful!';
      this.errorMessage = '';
      this.paymentForm.reset();

      // Wait 2 seconds before redirecting
      setTimeout(() => {
        this.successMessage = '';
        this.router.navigate(['/customer-dashboard']);
      }, 2000);
    },
    error: (err) => {
      this.errorMessage = '❌ Payment failed. Please try again.';
      this.successMessage = '';
      console.error(err);
    }
  });
}
}