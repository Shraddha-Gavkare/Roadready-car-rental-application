import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReservationService } from '../../services/reservation.service/reservation.service';

@Component({
selector: 'app-reservation-form',
standalone: true,
imports: [CommonModule, ReactiveFormsModule],
templateUrl: './reservation-form.html',
styleUrls: ['./reservation-form.css']
})
export class ReservationForm implements OnInit {
reservationForm: FormGroup;
errorMessage = '';
successMessage = '';

constructor(
private fb: FormBuilder,
private reservationService: ReservationService,
private router: Router
) {
this.reservationForm = this.fb.group({
carId: ['', Validators.required],
startDate: ['', Validators.required],
endDate: ['', Validators.required],
pickupLocation: ['', Validators.required],
dropoffLocation: ['', Validators.required]
});
}

ngOnInit(): void {}

onSubmit() {
if (this.reservationForm.invalid) {
this.errorMessage = 'All fields are required.';
this.successMessage = '';
return;
}

this.reservationService.reserveCar(this.reservationForm.value).subscribe({
next: () => {
this.successMessage = 'Car reserved successfully!';
this.errorMessage = '';
this.reservationForm.reset();
},
error: (err) => {
console.error('Reservation error:', err);
this.errorMessage = 'Reservation failed.';
this.successMessage = '';
}
});
}
}