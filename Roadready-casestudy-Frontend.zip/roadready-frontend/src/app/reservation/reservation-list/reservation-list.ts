import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReservationService } from '../../services/reservation.service/reservation.service';

@Component({
  selector: 'app-reservation-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reservation-list.html',
  styleUrls: ['./reservation-list.css']
})
export class ReservationList implements OnInit {
  reservations: any[] = [];
  errorMessage = '';

  constructor(private reservationService: ReservationService) {}

  ngOnInit() {
    this.reservationService.getUserReservations().subscribe({
  next: (data: any[]) => {
    this.reservations = data;  // <-- data should be an array
  },
  error: (err: any) => {
    console.error(err);
    this.errorMessage = 'Failed to load reservations';
  }
});

  }
}
