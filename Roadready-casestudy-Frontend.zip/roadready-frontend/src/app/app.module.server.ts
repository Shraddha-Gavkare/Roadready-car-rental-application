import { NgModule } from '@angular/core';
import { ServerModule } from '@angular/platform-server';
import { AppModule } from './app-module'; // ✅ corrected line
import { App } from './app';

@NgModule({
  imports: [
    AppModule,
    ServerModule,
  ],
  bootstrap: [App],
})
export class AppServerModule {}
