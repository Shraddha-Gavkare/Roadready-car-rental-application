import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Login } from './auth/login/login';
import { Register } from './auth/register/register';
import { CustomerDashboard } from './dashboard/customer-dashboard/customer-dashboard';
import { AdminDashboard } from './dashboard/admin-dashboard/admin-dashboard';
import { CarList } from './car/car-list/car-list';
import { ReservationForm } from './reservation/reservation-form/reservation-form';
import { AuthGuard } from './shared/guards/auth.guard/auth.guard';
import { ReservationList } from './reservation/reservation-list/reservation-list';
import { PaymentForm } from './payment/payment-form/payment-form';
import { PaymentList } from './payment/payment-list/payment-list';
import { ViewReservations } from './dashboard/admin-dashboard/view-reservations/view-reservations';
import { AdminReservations } from './dashboard/admin-reservations/admin-reservations';
import { AdminPayments } from './dashboard/admin-payments/admin-payments';
import { ViewUsers } from './view-users/view-users';
import { AboutUs } from './components/about-us/about-us';
import { CustomerProfile } from './dashboard/customer-dashboard/customer-profile';


const routes: Routes = [
{ path: '', redirectTo: 'login', pathMatch: 'full' },
{ path: 'login', component: Login },
{ path: 'register', component: Register },
{ path: 'cars', component: CarList },
{ path: 'reserve', component: ReservationForm },
{ path: 'my-payments', component: PaymentList },
{ path: 'admin/reservations', component: AdminReservations},
{ path: 'admin-dashboard/payments', component: AdminPayments},
{ path: 'admin/users', component: ViewUsers },

{
  path: 'admin/users',
  component: ViewUsers,
  canActivate: [AuthGuard],
  data: { role: 'ADMIN' }
},

{path: 'customer-dashboard', 
  component: CustomerDashboard, 
  canActivate: [AuthGuard], 
  data: { role: 'CUSTOMER' }},

{path: 'admin-dashboard',
component: AdminDashboard,
canActivate: [AuthGuard],
data: { role: 'ADMIN' }
},

{
  path: 'customer/profile',
  loadComponent: () => import('./dashboard/customer-dashboard/customer-profile')
    .then(m => m.CustomerProfile),
  canActivate: [AuthGuard],
  data: { role: 'CUSTOMER' }
},

{
  path: 'admin-dashboard/reports',
  loadComponent: () => import('./dashboard/admin-dashboard/admin-reports')
    .then(m => m.AdminReports),
  canActivate: [AuthGuard],
  data: { role: 'ADMIN' }
},

{
  path: 'about-us',
  loadComponent: () => import('./components/about-us/about-us').then(m => m.AboutUs)
},

{
path: 'admin-dashboard/car-management',
loadComponent: () => import('./dashboard/admin-dashboard/car-management/car-management')
.then(m => m.CarManagement),
canActivate: [AuthGuard],
data: { role: 'ADMIN' }
}, 

{
path: 'admin-dashboard/add-car',
loadComponent: () => import('./dashboard/admin-dashboard/add-car/add-car')
.then(m => m.AddCar),
canActivate: [AuthGuard],
data: { role: 'ADMIN' }
},

{
path: 'admin-dashboard/view-reservations',
component: ViewReservations,
canActivate: [AuthGuard],
data: { role: 'ADMIN' }
},

{
path: 'reserve',
component: ReservationForm,
canActivate: [AuthGuard],
data: { role: 'CUSTOMER' }
},

{
  path: 'my-payments',
  component: PaymentList,
  canActivate: [AuthGuard],
  data: { role: 'CUSTOMER' }
},

{
  path: 'make-payment',
  component: PaymentForm
},

{ path: 'reservations', 
  component: ReservationList },

{
  path: 'admin-dashboard/reservations',
  component: AdminReservations
},

{ path: '**', redirectTo: 'login' } // fallback
];

@NgModule({
imports: [RouterModule.forRoot(routes)],
exports: [RouterModule]
})

export class AppRoutingModule { }