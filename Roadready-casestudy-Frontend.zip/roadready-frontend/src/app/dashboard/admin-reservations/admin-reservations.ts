// admin-reservations.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // ✅ import this
import { ReservationService } from '../../services/reservation.service/reservation.service';

@Component({
  selector: 'app-admin-reservations',
  standalone: true, // ✅ indicates this is standalone
  imports: [CommonModule], // ✅ include CommonModule here
  templateUrl: './admin-reservations.html'
})
export class AdminReservations implements OnInit {
  reservations: any[] = [];

  constructor(private reservationService: ReservationService) {}

  ngOnInit(): void {
    this.fetchReservations();
  }

  fetchReservations() {
    this.reservationService.getAllReservations().subscribe(data => {
      this.reservations = data;
    });
  }

  deleteReservation(id: number) {
    if (confirm('Are you sure you want to delete this reservation?')) {
      this.reservationService.deleteReservation(id).subscribe(() => {
        this.fetchReservations();
      });
    }
  }
}
