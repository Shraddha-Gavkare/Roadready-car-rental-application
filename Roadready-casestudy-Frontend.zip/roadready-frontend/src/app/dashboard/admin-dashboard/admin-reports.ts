import { Component, OnInit } from '@angular/core';
import { ReportService } from '../../services/report.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-reports.html',
  styleUrls: ['./admin-reports.css']
})
export class AdminReports implements OnInit {

  revenue: number = 0;
  usage: number = 0;
  error: string = '';

  constructor(private reportService: ReportService) {}

  ngOnInit(): void {
    this.loadReports();
  }

  loadReports() {
    this.reportService.getRevenue().subscribe({
      next: (data) => this.revenue = data.value,
      error: (err) => this.error = 'Failed to load revenue'
    });

    this.reportService.getUsage().subscribe({
      next: (data) => this.usage = data.value,
      error: (err) => this.error = 'Failed to load usage'
    });
  }
}
