import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-footer',
  standalone: true,
  imports: [CommonModule],
  template: `<footer class="text-center py-3 bg-dark text-white">
                &copy; 2025 RoadReady Admin Panel | About Us | Contact
             </footer>`
})
export class AdminFooter {}