import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboard {

  cards = [
    { title: 'View All Cars', icon: 'fas fa-car', link: '/admin-dashboard/car-management', color: 'primary' },
    { title: 'Add Car', icon: 'fas fa-plus-circle', link: '/admin-dashboard/add-car', color: 'success' },
    { title: 'View Reservations', icon: 'fas fa-clipboard-list', link: '/admin-dashboard/reservations', color: 'warning' },
    { title: 'View Payments', icon: 'fas fa-credit-card', link: '/admin-dashboard/payments', color: 'info' },
    { title: 'View Users', icon: 'fas fa-users', link: '/admin/users', color: 'secondary' }, // ✅ FIXED PATH
    { title: 'Reports', icon: 'fas fa-chart-bar', link: '/admin-dashboard/reports', color: 'warning' }
  ];
 

  constructor(private router: Router) {}

  logout() {
    localStorage.clear();
    window.location.href = '/login';
  }

  goToReservations() {
    this.router.navigate(['/admin-dashboard/view-reservations']);
  }

  goTo(path: string) {
    this.router.navigate([`/admin/${path}`]);
  }
}
