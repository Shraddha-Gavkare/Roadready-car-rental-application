import {Component,OnInit} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HttpClient} from '@angular/common/http';

@Component({
selector: 'app-view-reservations',
standalone: true,
imports: [CommonModule],
templateUrl: './view-reservations.html',
styleUrls: ['./view-reservations.css']
})
export class ViewReservations implements OnInit {
reservations: any[] = [];
errorMessage = '';

constructor(private http: HttpClient) {}

ngOnInit(): void {
this.loadReservations();
}

loadReservations(): void {
this.http.get<any[]>('http://localhost:8080/api/reservations').subscribe({
next: data => this.reservations = data,
error: err => this.errorMessage = 'Failed to load reservations'
});
}
}