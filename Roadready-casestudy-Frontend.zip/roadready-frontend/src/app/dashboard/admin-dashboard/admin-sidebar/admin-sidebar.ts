import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `<div class="sidebar">
              <ul>
                <li><a routerLink="car-management">Manage Cars</a></li>
                <li><a routerLink="user-management">Manage Users</a></li>
                <li><a routerLink="reservation-management">Reservations</a></li>
              </ul>
            </div>`,
  styles: [`.sidebar { width: 200px; background: #343a40; color: white; min-height: 100vh; }
            ul { list-style: none; padding: 0; }
            li { padding: 12px; }
            a { color: white; text-decoration: none; display: block; }`]
})
export class AdminSidebar {}