import {
Component,
OnInit
} from '@angular/core';
import {
CommonModule
} from '@angular/common';
import {
FormsModule
} from '@angular/forms';
import {
CarService
} from '../../../services/car.service/car.service';

@Component({
selector: 'app-car-management',
standalone: true,
imports: [CommonModule, FormsModule],
templateUrl: './car-management.html',
styleUrls: ['./car-management.css']
})
export class CarManagement implements OnInit {
cars: any[] = [];
selectedCar: any = null;
searchId: number = 0;
errorMessage = '';
showTable = false;

constructor(private carService: CarService) {}

ngOnInit(): void {
this.getAllCars();
}

getAllCars(): void {
this.carService.getAllCars().subscribe({
next: data => {
this.cars = data;
this.selectedCar = null;
this.showTable = true;
},
error: err => this.errorMessage = 'Failed to fetch all cars'
});
}

getCarById(): void {
if (!this.searchId) return;
this.carService.getCarById(this.searchId).subscribe({
next: data => {
this.selectedCar = data;
this.showTable = false;
},
error: err => this.errorMessage = 'Car not found'
});
}

getAvailableCars(): void {
this.carService.getAvailableCars().subscribe({
next: data => {
this.cars = data;
this.selectedCar = null;
this.showTable = true;
},
error: err => this.errorMessage = 'Failed to fetch available cars'
});
}

deleteCar(id: number): void {
if (!confirm('Are you sure you want to delete this car?')) return;
this.carService.deleteCar(id).subscribe({
next: () => this.getAllCars(),
error: () => this.errorMessage = 'Failed to delete car'
});
}

editCar(car: any): void {
this.selectedCar = { ...car };
this.showTable = false;
}

updateCar(): void {
this.carService.updateCar(this.selectedCar.id, this.selectedCar).subscribe({
next: () => {
this.getAllCars();
this.selectedCar = null;
},
error: () => this.errorMessage = 'Failed to update car'
});
}

cancelEdit(): void {
this.selectedCar = null;
this.showTable = true;
}
}