import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CarService } from '../../../services/car.service/car.service';
import { Router } from '@angular/router';

@Component({
selector: 'app-add-car',
standalone: true,
imports: [CommonModule, FormsModule],
templateUrl: './add-car.html',
styleUrls: ['./add-car.css']
})
export class AddCar {
car = {
id: 0,
brand: '',
model: '',
year: new Date().getFullYear(),
color: '',
type: '',
pricePerDay: 0,
available: true,
licensePlate: ''
};

message = '';

constructor(private carService: CarService, private router: Router) {}

addCar() {
this.carService.addCar(this.car).subscribe({
next: () => {
this.message = 'Car added successfully!';
this.router.navigate(['/admin-dashboard/car-management']);
},
error: () => {
this.message = 'Failed to add car.';
}
});
}
}