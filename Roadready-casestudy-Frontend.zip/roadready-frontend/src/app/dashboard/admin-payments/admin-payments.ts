import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // ✅ required for *ngFor, *ngIf
import { HttpClientModule } from '@angular/common/http';
import { PaymentService } from '../../services/payment.service/payment.service';

@Component({
  selector: 'app-admin-payments',
  standalone: true,
  imports: [CommonModule, HttpClientModule], // ✅ add CommonModule here
  templateUrl: './admin-payments.html',
  styleUrls: ['./admin-payments.css']
})
export class AdminPayments implements OnInit {
  payments: any[] = [];

  constructor(private paymentService: PaymentService) {}

  ngOnInit(): void {
    this.fetchPayments();
  }

  fetchPayments() {
    this.paymentService.getAllPayments().subscribe({
      next: (data: any[]) => {
        this.payments = data;
      },
      error: (err: any) => {
        console.error('Error fetching payments:', err);
      }
    });
  }
}
