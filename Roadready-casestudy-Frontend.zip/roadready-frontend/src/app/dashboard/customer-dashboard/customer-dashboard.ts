import { Navbar } from '../../shared/navbar/navbar';
import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router'; // ✅ ADD THIS
import { CommonModule } from '@angular/common'; // ✅ Also required for *ngIf, etc.


@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [Navbar, RouterModule, CommonModule], // ✅ Add RouterModule here
  templateUrl: './customer-dashboard.html',
  styleUrls: ['./customer-dashboard.css']
})

export class CustomerDashboard implements OnInit {
  role: string | null = null;
  constructor(private router: Router) {}

  ngOnInit(): void {
    this.role = localStorage.getItem('role');
  }

  goToCars() {
    this.router.navigate(['/cars']);
  }

  goToReserve() {
    this.router.navigate(['/reserve']);
  }

  
  goToPayments() {
  this.router.navigate(['/my-payments']);
  }

  goToReservations() {
    this.router.navigate(['/reservations']);
  }

   goToPayment() {
  this.router.navigate(['/make-payment']);
}

logout() {
  localStorage.removeItem('token');
  this.router.navigate(['/login']);
}

goToProfile() {
  this.router.navigate(['/customer/profile']);
}
 


  
}
 
 
 
 

 
 
